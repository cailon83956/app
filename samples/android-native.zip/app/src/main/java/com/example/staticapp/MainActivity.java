package com.example.staticapp;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
